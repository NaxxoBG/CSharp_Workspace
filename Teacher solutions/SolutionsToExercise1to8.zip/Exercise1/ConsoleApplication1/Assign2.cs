﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
   class Assign2
   {
      public static void printnumbers()
      {
         for (int i = 0; i < 200; i++)
         {
            Console.WriteLine( i );
            Console.ReadKey();
            
         }
      }
   }
}
